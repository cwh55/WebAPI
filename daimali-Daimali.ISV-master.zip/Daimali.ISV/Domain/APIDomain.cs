﻿


namespace Daimali.ISV.Domain
{
    public class APIDomain
    {

    }
}